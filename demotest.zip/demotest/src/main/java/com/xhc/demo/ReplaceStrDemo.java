package com.xhc.demo;

/**
 * @author ：xhc
 * @version ：1.0
 * @program ：demo
 * @date ：Created in 2024/07/07 11:11
 * @description ：计算类
 */
public class ReplaceStrDemo {

    /**
     * 获取字母a--z的某个字母的前一个字母
     * @param letter
     * @return
     */
    public static Character getPreviousLetter(char letter) {
        if (letter < 'a' || letter > 'z') {
            throw new IllegalArgumentException("The input letter must be a lowercase letter between 'a' and 'z'.");
        }
        if (letter == 'a') {
            return null;
        }
        return (char) (letter - 1);
    }

    /**
     * 连续出现3次以上字符被替换成前面的字符串
     * 按字母顺序排在它前面的单个字符。
     * @param string
     */
    public static void replaceRepeatStr(StringBuilder string) {
        int i = 0;
        boolean found = false;
        while (i < string.length()) {
            int j = i + 1;
            while (j < string.length() - 1 && string.charAt(i) == string.charAt(j) && string.charAt(j) == string.charAt(j + 1)) {
                j++;
                found = true;
            }
            if (found) {
                char currentChar=string.charAt(i);
                Character preChar= getPreviousLetter(currentChar);
                System.out.println("currentChar:"+currentChar+"preChar:"+preChar);
                string.replace(i, j + 1,preChar!=null?String.valueOf(preChar):"");
                System.out.println("+:"+string);
                if (i!= 0) {
                    i = 0;
                }
                found = false;
            } else {
                i++;
            }
        }
    }


}
