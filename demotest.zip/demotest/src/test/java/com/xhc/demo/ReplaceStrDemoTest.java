package com.xhc.demo;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author ：xhc
 * @version ：1.0
 * @program ：demo
 * @date ：Created in 2024/07/07 11:11
 * @description ：计算类
 */
public class ReplaceStrDemoTest {




    @Test
    public void testGetPreviousLetterOne(){
        char letter = 'd'; // 示例字母
        char previousLetter = ReplaceStrDemo.getPreviousLetter(letter);
        System.out.println("The previous letter of '" + letter + "' is '" + previousLetter + "'");
        Assert.assertEquals(String.valueOf(previousLetter),"c");
    }
    @Test
    public void testGetPreviousLetterTwo(){
        char letter = 'a'; // 示例字母
        Character previousLetter = ReplaceStrDemo.getPreviousLetter(letter);
        System.out.println("The previous letter of '" + letter + "' is '" + previousLetter + "'");
        Assert.assertNull(previousLetter);
    }

    @Test(expected = RuntimeException.class)
    public void testGetPreviousLetterThree(){
        char letter = 'E'; // 示例字母
        Character previousLetter = ReplaceStrDemo.getPreviousLetter(letter);
    }


    @Test
    public void testReplaceRepeatStrTwo(){
        String input ="";
        input="abcccbad";
        StringBuilder string = new StringBuilder(input);
        ReplaceStrDemo.replaceRepeatStr(string);
        System.out.println(string.toString());
        Assert.assertEquals(string.toString(),"d");
    }

}
